#!/bin/bash
export NGINX_UPSTREAM=$(gawk '{ match($0, /@([^@:]+?):[0-9]+$/, m); print m[1] }' <<< $NEO4J_URL):7474
"$@"